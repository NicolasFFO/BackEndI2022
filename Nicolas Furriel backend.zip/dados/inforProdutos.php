<?php 
	$produtos = array(
		   array("titulo" => "MARMITA", "nome" => "Spaguetti ao Pesto com Tomates Assados (Vegano)", "Tamanho" => "Média", "valor" => "12,50", "img" => "images/spagueti.JPG", "ingredientes" => "1 chávena couve kale cortada aos pedaços (sem talo)<br>
												1 chávena folhas de manjericão<br>
												1/3 chávena sementes de abóbora (ou outro fruto seco ou semente)<br>
												1/4 chávena sementes de cânhamo (opcional mas enriquece nutricionalmente)<br>
												2 dentes de alho (descascados)<br>"),

		    array("titulo" => "MARMITA", "nome" => "Marmita Saudável", "Tamanho" => "Grande", "valor" => "22,30", "img" => "images/marmita_saudavel.JPG", "ingredientes" => "11 xícara de chá de tapioca hidratada, Sal a gosto<br>
												75 g de cream cheese (ou creme de ricota light)<br>
												40 g de queijo minas curado (ou parmesão) ralado<br>
												Sal a gosto<br>
												1 colher de sopa de linhaça (ou chia)<br>"),

	 		array("titulo" => "MARMITA", "nome" => "Marmita Caseira", "Pequena" => "Grande", "valor" => "12,40", "img" => "images/marmita_caseira.JPG", "ingredientes" => "500g de peito de frango<br>
						2 xícaras (chá) de suco de laranja<br>
						¼ xícara (chá) de azeite<br>
						1 colher (sopa) de amido de milho<br>
						Sal, pimenta do reino e temperos a gosto) <br>
						 Primeiramente, corte o peito de frango em tiras médias de um dedo <br>"),

		 
		);

	

 ?>